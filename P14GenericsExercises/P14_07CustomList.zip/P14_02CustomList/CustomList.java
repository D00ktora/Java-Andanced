/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 25.3.2023 г.
 * Time: 7:05
 */
package P14_02CustomList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CustomList<T extends Comparable> {

    private List<T> tList = new ArrayList<>();


    public void add(T element) {
        this.tList.add(element);
    }

    public T remove(int index) {
        return this.tList.remove(index);
    }

    public boolean contains(T element) {
        return this.tList.contains(element);
    }

    public void swap(int from, int to) {
        T tempElement = this.tList.get(from);
        this.tList.set(from, this.tList.get(to));
        this.tList.set(to, tempElement);
    }

    public int countGreaterThan(T element) {
        int count = 0;
        for (T t : tList) {
            if (t.compareTo(element) > 0) {
                count++;
            }
        }
        return count;
    }

    public T getMax() {
        T t = this.tList.stream().max((f, s) -> f.compareTo(s)).get();
        return t;
    }

    public T getMin() {
        T t = this.tList.stream().min((f, s) -> f.compareTo(s)).get();
        return t;
    }

    public void print() {
        for (T t : tList) {
            System.out.println(t);
        }
    }

}
