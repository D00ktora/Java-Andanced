/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 21.3.2023 г.
 * Time: 20:42
 */
package P14_01GenericBox;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numberOfInputs = Integer.parseInt(scanner.nextLine());
        Box<String> box = new Box<>();
        for (int i = 0; i < numberOfInputs; i++) {
            String input = scanner.nextLine();
            box.getTypes().add(input);
        }
        String input = scanner.nextLine();
        int number1 = Integer.parseInt(input.split("\\s+")[0]);
        int number2 = Integer.parseInt(input.split("\\s+")[1]);
        box.swap(number1, number2);

        System.out.println(box.toString());
    }
}
