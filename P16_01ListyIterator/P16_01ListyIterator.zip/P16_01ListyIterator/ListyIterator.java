/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 25.3.2023 г.
 * Time: 14:53
 */
package P16_01ListyIterator;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


public class ListyIterator {
    private List<String> list;
    private int counter = 0;
    public boolean move() {
        boolean result = this.counter < this.list.size() - 1;
        if (result == true) {
            this.counter++;
        }
        return result;
    }
    public boolean hasNext() {
        return this.counter < this.list.size() - 1;
    }

    public void print() {
        if (this.list.isEmpty()) {
           throw new IllegalArgumentException("Invalid Operation!");
        } else {
            System.out.println(this.list.get(this.counter));
        }
    }

    public ListyIterator(String... list) {
        this.list = Arrays.stream(list).collect(Collectors.toList());
    }

}
