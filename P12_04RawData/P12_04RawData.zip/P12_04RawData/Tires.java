/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 19.3.2023 г.
 * Time: 15:57
 */
package P12_04RawData;

public class Tires {
    private double tirePressure1;
    private int tireAge1;
    private double tirePressure2;
    private int tireAge2;
    private double tirePressure3;
    private int tireAge3;
    private double tirePressure4;
    private int tireAge4;

    public Tires(double tirePressure1, int tireAge1, double tirePressure2, int tireAge2, double tirePressure3, int tireAge3, double tirePressure4, int tireAge4) {
        this.tirePressure1 = tirePressure1;
        this.tireAge1 = tireAge1;
        this.tirePressure2 = tirePressure2;
        this.tireAge2 = tireAge2;
        this.tirePressure3 = tirePressure3;
        this.tireAge3 = tireAge3;
        this.tirePressure4 = tirePressure4;
        this.tireAge4 = tireAge4;
    }

    public double getTirePressure1() {
        return tirePressure1;
    }

    public void setTirePressure1(double tirePressure1) {
        this.tirePressure1 = tirePressure1;
    }

    public int getTireAge1() {
        return tireAge1;
    }

    public void setTireAge1(int tireAge1) {
        this.tireAge1 = tireAge1;
    }

    public double getTirePressure2() {
        return tirePressure2;
    }

    public void setTirePressure2(double tirePressure2) {
        this.tirePressure2 = tirePressure2;
    }

    public int getTireAge2() {
        return tireAge2;
    }

    public void setTireAge2(int tireAge2) {
        this.tireAge2 = tireAge2;
    }

    public double getTirePressure3() {
        return tirePressure3;
    }

    public void setTirePressure3(double tirePressure3) {
        this.tirePressure3 = tirePressure3;
    }

    public int getTireAge3() {
        return tireAge3;
    }

    public void setTireAge3(int tireAge3) {
        this.tireAge3 = tireAge3;
    }

    public double getTirePressure4() {
        return tirePressure4;
    }

    public void setTirePressure4(double tirePressure4) {
        this.tirePressure4 = tirePressure4;
    }

    public int getTireAge4() {
        return tireAge4;
    }

    public void setTireAge4(int tireAge4) {
        this.tireAge4 = tireAge4;
    }
}
