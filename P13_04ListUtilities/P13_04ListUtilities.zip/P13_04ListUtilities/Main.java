/**
 * Created by IntelliJ IDEA
 * User: Stilyan Petrov
 * Date: 21.3.2023 г.
 * Time: 20:31
 */
package P13_04ListUtilities;

public class Main {
    public static void main(String[] args) {

    }
}
